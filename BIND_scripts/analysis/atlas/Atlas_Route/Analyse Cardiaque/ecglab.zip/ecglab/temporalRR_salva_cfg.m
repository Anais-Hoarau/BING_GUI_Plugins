function temporalRR_salva_cfg(filename,abscissa,unidade_eixox,eixox1,eixox2,eixoy1,eixoy2,minimox,limitex,outliers)

save temporalRR_params.mat abscissa unidade_eixox eixoy1 eixoy2 outliers;
