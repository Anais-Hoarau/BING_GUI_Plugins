function espectralRR_salva_cfg(filename,vlf2,lf2,hf2,ordem_ar,escala,maxF,minF,minP,maxP,algoritmo,metodo,fs,janela,N,fill);

save espectralRR_params.mat vlf2 lf2 hf2 ordem_ar escala maxF minF minP maxP algoritmo metodo fs janela N fill;
