function [vlf2,lf2,hf2,ordem_ar,escala,maxF,minF,minP,maxP,algoritmo,metodo,fs,janela,N,fill]=espectralRR_le_cfg(filename);

load espectralRR_params.mat;
