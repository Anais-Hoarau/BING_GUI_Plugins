disp('This module has been renamed to SpectralRR')
spectralrr